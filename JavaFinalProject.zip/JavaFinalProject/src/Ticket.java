
public class Ticket {
	int ticket_ID;
	String ticketName; /// "Regular", "Premium" or "Business".
	int biman_ID;
	int user_id;
	int price;
}
